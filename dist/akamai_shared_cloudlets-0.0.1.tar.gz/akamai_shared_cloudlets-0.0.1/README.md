# Akamai shared cloudlets library
## Purpose
This python library should (and could) serve as the basic building block for any application that 'wants' to work with Akamai Shared Cloudlets (for more information about Akamai cloudlets, see https://techdocs.akamai.com/cloudlets/reference/api).

For whatever reason, Akamai have not put much effort in implementing the shared cloudlets into their automation products (such as Akamai CLI https://github.com/akamai/cli or Terraform Akamai provider https://registry.terraform.io/providers/akamai/akamai/latest/docs/guides/get_started_cloudlets).

## Usage
...tbd...